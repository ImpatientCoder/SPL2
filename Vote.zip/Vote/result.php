<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Election Pole</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div id="heading"> <h2>This is the result page of Online Election</h2></div>


<?php
        //Operation for "View results..!"    
         if(isset($_GET['results']))  
         {
             require '../EC/dbh.inc.php';

             $sql = "SELECT* FROM president";
             $result = mysqli_query($connection, $sql);

             $totalCount = 0;
             while($row = mysqli_fetch_assoc($result))
             {
                    $totalCount += $row['count'];
             }

             $sql = "SELECT* FROM president";
             $result = mysqli_query($connection, $sql);

             while($row = mysqli_fetch_assoc($result))
             {?>
                <div style='background: white; text-align:center; color: chocolate; padding: 10px;'>
                    <table class="table">
                        <tr>
                            <th><h2><?php echo $row['id'].".&nbsp;&nbsp;&nbsp;&nbsp;"; ?></h2></th>
                            <th><h2><?php echo $row['username']."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; ?></h2></th>
                            <td><h2><?php echo $row['count']."(".round($row['count']*100/$totalCount)."%)"; ?></h2></td>
                        </tr>
                    </table>
                </div>
            
            <?php     
             }

         }
?> 

<div id="heading"> <h2>This is the result page of Online Election</h2></div>
</body>
</html>

             <!-- //echo "&nbsp;&nbsp;&nbsp;&nbsp;Ramesh is learning PHP"."<br/>";
             // echo "
             //    <div style='background:orange; text-align:center; padding: 10px;'>
             //        <center>
             //            <h2>Updated result</h2>   
             //            <p style='background: black; color:white; padding: 10px; width:50%;'>
             //                <b>Lionel Messi: </b>$messi($per_messi)
             //            </p>
             //            <p style='background: black; color:white; padding: 10px; width:50%;'>
             //                <b>Cristiano Ronaldo: </b>$ronaldo($per_ronaldo)
             //            </p>
             //            <p style='background: black; color:white; padding: 10px; width:50%;'>
             //                <b>Neymar: </b>$neymar($per_neymar)
             //            </p>
             //        </center>
             //    </div>
             // ";   -->