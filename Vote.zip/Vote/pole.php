<?php 
	session_start();
    $voterid = $_SESSION['id'];	

	require '../EC/dbh.inc.php';	
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Election Pole</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
	   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <link rel="stylesheet" href="style.css">
</head>
<body>
 
 <div id="heading"><h2>Vote for your favourite president</h2></div>
 
  <div class="container">
  	<table class="table table-bordered">
    	<form action="pole.php" method="post" align="center">

    		<?php
    			$sql = "SELECT * FROM candidate";
				$result= mysqli_query($connection, $sql);

			    while($row = mysqli_fetch_assoc($result))
			    { 
			        if($row['status']=='approved' && $row['post']=='president')
			        {
			        	$id = $row['id'];
			        	$username= $row['username'];

			        	$sql2 = "INSERT INTO president (id, username) VALUES('$id', '$username')";	
			        	mysqli_query($connection, $sql2);
			        	?>

			        	<tr>
				        	<th class="text-center"><h2><?php echo $row['username'] ?></h2></th>
				        	<td>..........</td>
				        	<td>Votefor <input type="submit" name="pname" value="<?php echo $row['username'] ?>" onclick="return confirm('Are you sure to vote?')"></td>
			        	</tr>
					<?php
			        }
				}
			?>
    	</form>    
    </table>	         
  </div>


 <div id="heading"> <h2>Vote for your favourite secretary</h2></div>

<div class="container">
	<table class="table table-bordered">
		<form action="pole.php" method="post" align="center">
    		<?php
    			$sql = "SELECT * FROM candidate";
				$result= mysqli_query($connection, $sql);

			    while($row = mysqli_fetch_assoc($result))
			    { 
			        if($row['status']=='approved' && $row['post']=='secretary')
			        {
			        	$id = $row['id'];
			        	$username= $row['username'];

			        	$sql2 = "INSERT INTO secretary (id, username) VALUES('$id', '$username')";	
			        	mysqli_query($connection, $sql2);

			        	?>
			        	<tr>
				        	<th class="text-center"><h2><?php echo $row['username'] ?></h2>  </th>
				        	<td>..........</td>
				        	<td>Votefor<input type="submit" name="sname" value="<?php echo $row['username'] ?>" onclick="return confirm('Are you sure to vote?')"></td>
			        	</tr>
					<?php
			        }
				}
			?>
	    </form>    
    </table>	
</div>

 <?php 

  	  $voter_sql = "SELECT * FROM voter WHERE id = $voterid";
  	  $voter_result= mysqli_query($connection, $voter_sql);
  	  $voter_row = mysqli_fetch_assoc($voter_result);	

      if(isset($_POST['pname']))
      {
      	  if($voter_row['pcast']=="false")
      	  {
      	  		  $voter_sql2 = "UPDATE voter SET pcast='true' WHERE id = $voterid";
  	  			  $voter_result2= mysqli_query($connection, $voter_sql2);

      	  		  echo $_POST['pname'];	
		      	  $name = $_POST['pname'];


		      	  $sql = "SELECT * FROM president";
		      	  $result= mysqli_query($connection, $sql);

		      	  while ($row = mysqli_fetch_assoc($result)) 
		      	  {
		      	  	if ($name == $row['username']) 
		      	  	{
		      	  		  $vote = "UPDATE president SET count=count+1 WHERE username = '$name' ";
				          $run = mysqli_query($connection, $vote);
				          
				          if($run)
				          {
				              echo "<h2 align='center'>Your vote has been casted for $name</h2>";
				              echo "<h2 align='center'><a href='result.php?results'>View Results</a></h2>";
				          }
		      	  	     
		      	  	}
		      	  }

      	  }
      	  else
      	  {
      	  	echo "<h2 align='center'>Don't try to duplicate vote!</h2>";
      	  	echo "<h2 align='center'>You have already casted your vote...!!!</h2>";
      	  	echo "<h2 align='center'><a href='result.php?results'>View Results</a></h2>";
      	  }



      }
      if(isset($_POST['sname']))
      {
	      	if($voter_row['scast']=="false")
	      	{
	      		  $voter_sql2 = "UPDATE voter SET scast='true' WHERE id = $voterid";
  	  			  $voter_result2= mysqli_query($connection, $voter_sql2);

				  echo $_POST['sname'];	
		      	  $name = $_POST['sname'];

		      	  $sql = "SELECT * FROM secretary";
		      	  $result= mysqli_query($connection, $sql);

		      	  while ($row = mysqli_fetch_assoc($result)) 
		      	  {
			      	  	if ($name == $row['username']) 
			      	  	{
			      	  		  $vote = "UPDATE secretary SET count=count+1 WHERE username = '$name' ";
					          $run = mysqli_query($connection, $vote);
					          
					          if($run)
					          {
					              echo "<h2 align='center'>Your vote has been casted for $name</h2>";
					              echo "<h2 align='center'><a href='result.php?results'>View Results</a></h2>";
					          }
			      	  	     
			      	  	}
		      	  }

	      	}
	        else
      	    {
      	  	   echo "<h2 align='center'>Don't try to duplicate vote!</h2>";
      	  	   echo "<h2 align='center'>You have already casted your vote...!!!</h2>";
      	  	   echo "<h2 align='center'><a href='result.php?results'>View Results</a></h2>";
      	    }
       }
   ?>

</body>
</html>



<!-- <div>
   <img src="../images/messi.jpg" width="280" height="250" alt="Messi"><br>
   <input type="submit" name="messi" value="Vote for Messi">
</div>

<div>
   <img src="../images/Cristiano-Ronaldo.jpg" width="280" height="250" alt="Ronaldo"><br>
   <input type="submit" name="ronaldo" value="Vote for Ronaldo">   
</div>

<div>
   <img src="../images/Neymar_Junior_the_Future_of_Brazil.jpg" width="280" height="250" alt="Neymar"><br>    
   <input type="submit" name="neymar" value="Vote for Neymar">
</div>   -->  

