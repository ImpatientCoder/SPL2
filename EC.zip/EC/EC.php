<?php 
    session_start();
 ?>

<?php require 'loginHeader.php'; ?>  
 

<div class="container">
  <?php 
    echo $_SESSION['uid'];
    if (isset($_SESSION['uid'])) 
    {
      echo "<p><b>You are logged in!</b></p>";
    }
  ?> 
  <h3>Election commissioner's page of online voting system</h3>
    <p>This example shows how a candidate will perform his jobs.</p>
  <br>
</div>
<div class="container">
    <div class="row">
        <div class="col-sm-4 request">
            Request-->Approve, Remove.            
        </div>
        <div class="col-sm-7 updates">
             Election updates and news<br>
        </div>
    </div>
</div>


<?php 
    require 'ecFooter.php';
 ?>
