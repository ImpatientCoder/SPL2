<?php require 'cHeader.php'; ?>
  
<div class="container">
  <h3>Candidates's page of online voting system</h3>
    <p>This example shows how an ec will perform his jobs.</p>
  <br>
</div>
<div class="container">
    <div class="row">
        <div class="col-sm-4 request">
            New notification
            <br>Profile card image            
        </div>
        <div class="col-sm-7 updates">
            Casting Votes<br>
            Pole<br>
             Election updates and news
        </div>
    </div>
</div>

<?php require 'cFooter.php'; ?>

