<?php
    session_start();
    $id =$_SESSION['id'];
    require "../EC/dbh.inc.php";

    $sql = "SELECT* FROM candidate WHERE id = $id";
    $result = mysqli_query($connection, $sql);
    $candidate = mysqli_fetch_assoc($result);
?>


<?php require 'cHeader.php'; ?>

<div class="container">
    <div class="row">
        <div class="col-sm-5" style="background-color: skyblue;">
            <br>Some photos and pictures about the election<br>
            Carousel/Slide show             
        </div>
        <div class="col-sm-6" style="background-color: antiquewhite; margin-left: auto; border-radius: 10px;">
             <h3>Update your profile</h3><br>
             <table class="table">
                <form id="design" action="cupdate.inc.php" method="post">
                    <tr>
                        <th class="text-center">Name: </th>
                        <td><input type="text" name="uid" value="<?php echo $candidate['username']; ?>" class="form-control"></td>
                    </tr>
                    <tr>
                        <th class="text-center">Email: </th>
                        <td><input type="email" name="email" value="<?php echo $candidate['email']; ?>" class="form-control"></td>
                    </tr>
                    <tr>
                        <th class="text-center">Password: </th>
                        <td><input type="password" name="pwd" placeholder="Enter Password" class="form-control"></td>
                    </tr>
                    <tr>
                        <th class="text-center">Confirm: </th>
                        <td><input type="password" name="repeat-pwd" placeholder="Repeat Password" class="form-control"></td>
                    </tr>
                    <tr>
                        <th class="text-center">Address: </th>
                        <td><input type="text" name="address" value="<?php echo $candidate['address'];?>" placeholder="Optional" class="form-control"></td>
                    </tr>
                    <tr>
                        <th class="text-center">Contact no: </th>
                        <td><input type="text" name="contact" placeholder="Optional" value="<?php echo $candidate['contact'];?>" class="form-control"></td>
                    </tr> 
                    <tr>
                        <th></th>
                        <td class="text-right"><button type="submit" class="btn btn-primary" name="update-submit">Update</button></td>
                    </tr>              
                </form>
            </table>

            <?php
                  if (isset($_GET['error']))
                  {
                    if ($_GET['error'] == "emptyfield")
                    {
                      echo '<p><b>Fill up all the input fields</b></p>';
                    }
                    elseif ($_GET['error'] == "UserAlreadyExists")
                    {
                      echo '<p><b>This id is already exists</b></p>';
                    }
                    elseif ($_GET['error'] == "InvalidEmail&Username")
                    {
                      echo '<p><b>Invalid email and username</b></p>';
                    }     
                    elseif ($_GET['error'] == "InvalidEmail")
                    {
                      echo '<p><b>Email is invalid</b></p>';
                    }
                    elseif ($_GET['error'] == "InvalidUsername")
                    {
                      echo '<p><b>Username is invalid</b></p>';
                    }
                    elseif ($_GET['error'] == "passwordNotMatch")
                    {
                      echo '<p><b>Password not matched to the previous one</b></p>';
                    }   
                    elseif ($_GET['error'] == "emailDuplicate")
                    {
                      echo '<p><b>Email duplication..! You cannot use the email of another voter..!</b></p>';
                    } 
                  }
                  elseif (isset($_GET['update']) == "success")
                  {
                    echo '<p><b>Your profile is updated now..!!!</b></p>';
                  }
             ?>  
        </div>
    </div>
</div>


<?php require 'cFooter.php'; ?>
