<?php 
  require '../EC/ecHeader.php';
?>

<div class="container">
  <h3>Voter sign in page of online voting system</h3><br><br> 
</div>
<div class="container">
    <div class="row">
        <div class="col-sm-5" style="background-color: skyblue;">
            <br>Some photos and pictures about the election<br>
            Carousel/Slide show             
        </div>
        <div class="col-sm-6" style="background-color: aquamarine; margin-left: auto; border-radius: 10px">
             <table class="table">
                 <h3>Sign in</h3>
                  <form id="design" action="vsignin.inc.php" method="post">
                      <div><input type="text" name="uid" placeholder="Enter Username" class="form-control"></div>
                      <div><br><input type="password" name="pwd" placeholder="Enter Password" class="form-control"></div>
                      <div><br><button type="submit" class="btn btn-info" name="signin-submit">Submit</button></div><br>                  
                </form>
            </table>
            <?php
                  if (isset($_GET['error']))
                  {
                    if ($_GET['error'] == "emptyfields")
                    {
                      echo '<p><b>Fill up all the input fields</b></p>';
                    }
                    elseif ($_GET['error'] == "noUser")
                    {
                      echo '<p><b>There are no user by this name</b></p>';
                    }
                    elseif ($_GET['error'] == "WrongPassword")
                    {
                      echo '<p><b>Invalid username or password</b></p>';
                    }  
                    elseif ($_GET['error'] == "notApproved")
                    {
                      echo '<p><b>Your request is in processing...!!!</b></p>';
                    }  
                          
                  }
             ?>  
        </div>
    </div>
</div>


<?php
  require '../Home/footer.php';
?>

