<?php 
    require 'adminHeader.php';
 ?>

<body>
    <div class="wrapper">
        <?php 
            require 'sidebar.php';
         ?>    
        <div id="content">
            <?php
                 require 'navbar.php';
             ?>
            <div class="container">
                <div class="row">
                    <div class="col-sm-5" style="background: skyblue;  margin-left: 5%; border-radius: 20px;">
                        <img src="Google_Contacts_logo.png"  width="150" height="150" align= "center"><br>
                        <big><b>Md. Samsarabbi Suborno </b></big><br/>
                            R-14,Noorjahan Road<br/>Mohammadpur Dhaka-1207<br/>
                            Email:BSSE0916@iit.du.ac.bd<br/>
                            Tel:01784919174<br/>
                            <br/>
                    </div>
                    <div class="col-sm-5" style="background: skyblue;  margin-left: 5%; border-radius: 20px;">
                        <img src="Google_Contacts_logo.png"  width="150" height="150" align= "center"><br>
                        <big><b>Md. Alamgir Kabir, Software Engineering, (IIT)</b></big><br><br>
                            <b> Amar Ekushey Hall, 
                                University of Dhaka<br>
                                Email: bsse0907@iit.du.ac.bd<br/>
                                Tel: 01521248309<br/>
                                <br/>
                            </b>
                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php 
    require 'adminFooter.php';
  ?>

</body>

</html>