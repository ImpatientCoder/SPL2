<?php 
    require 'adminHeader.php';
 ?>

<body>
    <div class="wrapper">
 
      <?php 
          require 'sidebar.php';
       ?>

        <!-- Page Content  -->
      <div id="content">

          <?php 
              require "navbar.php";
           ?>


       		<img src="myphoto.jpg"  width="125" height="125" align= "right">
       		<big><b>Md. Samsarabbi Suborno </b></big><br/>
       		R-14,Noorjahan Road<br/>Mohammadpur Dhaka-1207<br/>
       		Email:BSSE0916@iit.du.ac.bd<br/>
       		Tel:01784919174<br/>
       		<br/>
       		<br/>
       		<big><b>Career Objective</b></big>
       		 <HR ALIGN=left>  	
         		human being
         		<br/>
       		<br/>
         		<big><b>Present Status</b></big>
         		 <HR ALIGN=left>  	
         		Student<br>honors 3rd year<br>IIT,University of Dhaka
         		<br/>
       		<br/>
       		<big><b>Education</b></big>
       		<HR ALIGN=left>  
 		<table border="1" cellpadding="10" cellspacing="0" width="100%">
 			
 				<tr>
 					<th>Exam</th><th>Board/University</th><th>Year</th><th>Name of Institution</th><th>Marks </th>
 				</tr>
            <tr>
               <td>JSC</td><td>Dinajpur</td><td>2011</td><td>Thakurgaon Goverment Boy's High school</td><td>4.72</td>
            </tr>
 				<tr>
 					<td>SSC</td><td>Dinajpur</td><td>2014</td><td>Thakurgaon Goverment Boy's High school</td><td>5.00</td>
 				</tr>
 				<tr>
 					<td>HSC</td><td>Dhaka</td><td>2016</td><td>Cambrian College</td><td>5.00</td>
 				</tr>
 				<!--<tr>
 					<td>BSSE</td><td>University of Dhaka</td><td>2021</td><td>Institute of Information Technology</td><td>2.93</td>
 				</tr>-->
 		</table>
 		<br/>
 		<br/>
 		<big><b>Computer Skills</b></big>
 		<HR ALIGN=left> 

 			<table border="0">
 				<tr>
 					<td align= "left">Programming Language</td><td>:</td><td>C,C++,java</td>
 				</tr>
 				<tr>
 					<td align= "left">Web based skills</td><td>:</td><td>HTML</td>
 				</tr>
 				<tr>
 					<td align= "left">Database skills</td><td>:</td><td>Sqlite</td>
 				</tr>
 				<tr>
 					<td align= "left">Scripting</td><td>:</td><td>N/A</td>
 				</tr>
 				<tr>
 					<td align= "left">Development Tools</td><td>:</td><td>GCC,Eclipse,pycharm</td>
 				</tr>
 				<tr>
 					<td align= "left">Others</td><td>:</td><td>MS Word,Powerpoint,Excel</td>
 				</tr>
		</table>
 		<br/>
 		<br/>
   		<big><b>Professional Expreience</b></big>
   		 <HR ALIGN=left> 
            N/A

   		<br/>
 		<br/>
   		<big><b>Projects</b></big>
   		 <HR ALIGN=left> 
             N/A

   		 <br/>
 		<br/>
   		<big><b>Academic Projects</b></big>
   		<HR ALIGN=left> 
   		<h4>Implementing operating system scheduling algorithms</h4>
   		 <b>Project description:</b>
		    The aim of this project is to implementing five operating system scheduling algorithm. These algorithms are:<br/>
          <ul>
             <li>First-come first -Served(FCFS)</li>
             <li>Shortest -job fast(SJF)</li>
             <li>Priority Scheduling</li>
             <li>Banker’s Algorithm</li>
             <li>Page replacement</li>
             <ul><li>FIFO</li><li>Optimal</li><li>LRU</li></ul>
          </ul>
				
   		<br/>
 		<br/>
   		<big><b>Achievements</b></big>
   		 <HR ALIGN=left> 
               N/A

   		 <br/>
 		<br/>
   		<big><b>Language</b></big>
   		 <HR ALIGN=left> 
   		 <ul>
            <li>Bangla</li>    
            <li>English</li>
            <li>Hindi</li>
         </ul>

   		 <br/>
 		<br/>
   		<big><b>Personal Information</b></big>
   		 <HR ALIGN=left> 
          <table border="0" align="center">
             <tr>
               <td align= "left">Full Name</td><td>:</td><td>Md Samsarabbi Suborno</td>
            </tr>
            <tr>
               <td align= "left">Father's Name</td><td>:</td><td>Md. Lutfar Rahman</td>
            </tr>
            <tr>
               <td align= "left">Mother's Name</td><td>:</td><td>Selina Akther</td>
            </tr>
            <tr>
               <td align= "left">Date of Birth</td><td>:</td><td>19/10/1998</td>
            </tr>
            <tr>
               <td align= "left">Sex</td><td>:</td><td>Male</td>
            </tr>
            <tr>
               <td align= "left">Marital Status</td><td>:</td><td>Unmarried</td>
            </tr>
            <tr>
               <td align= "left">Nationallity</td><td>:</td><td>Bangladeshi</td>
            </tr>
            <tr>
               <td align= "left">Religion</td><td>:</td><td>Islam</td>
            </tr>
            <tr>
               <td align= "left">Blood Group</td><td>:</td><td>A+</td>
            </tr>
            <tr>
               <td align= "left">Present Address</td><td>:</td><td>R-14,Noorjahan Road,Mohammadpur Dhaka-1207<br/>
              </td>
            </tr>
            <tr>
               <td align= "left">Permanent Address</td><td>:</td><td>House no:830,Sarkarpara,Thakurgaon sodor,Thakurgaon</td>
            </tr>
          </table>

   		 <br/>
 		<br/>
   		<big><b>Hobbies</b></big>
   		 <HR ALIGN=left> 
          <ul>
             <li>Playing video games</li>
             <li>Watching movie</li>
             <li>Listening songs</li>
          </ul>

 		<br/>
   		<big><b>Games</b></big>
   		 <HR ALIGN=left> 
          <ol>
             <li>Cricket</li>
             <li>Badminton</li>
             <li>Football</li>
          </ol>

 		<br/>
   		<big><b>References</b></big>
   		 <HR ALIGN=left> 
          <big><b>Mohd. Zulfiquar Hafiz</b></big><br>
            Professor<br>IIT, University of Dhaka<br>Email:zhjewel@iit.du.ac.bd<br>Tel:01713452223<br>
            <br>
            <br>
          <big><b>Nadia Nahar</b></big><br>
            Lecturer<br>IIT, University of Dhaka<br>Email:nadia@iit.du.ac.bd<br>Tel:01674896863<br>  



          <br>
          <br>
            <p align=center >copyright &copy; Samsarabbi, 2019</p>

        </div>
    </div>
  

  
    <?php 
        require 'adminFooter.php';
     ?>

</body>

</html>