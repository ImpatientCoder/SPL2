<!-- Sidebar  -->
<nav id="sidebar">
    <div class="sidebar-header">
       <a href="Admin.php"><h2>Admin Panel</h2></a>
    </div>
    <ul class="list-unstyled components">
        <li class="">
            <a href="Home.php">Home</a>
        </li>
        <li>
            <a href="#">Inbox</a>
        </li>
        <li>
            <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Management</a>
            <ul class="collapse list-unstyled" id="pageSubmenu">
                <li>
                    <a href="#">Admin</a>
                </li>
                <li>
                    <a href="ecManagement.php">Election Commissioner</a>
                </li>
            </ul>
        </li>
        <li>
            <a href="AboutAdmin.php">About</a>
        </li>
        <li>
            <a href="Contact.php">Contact</a>
        </li>  
    </ul>
    <ul class="list-unstyled CTAs">
        <li>
            <a href="#" class="download"><b>Logout</b></a>
        </li>
    </ul>
</nav>